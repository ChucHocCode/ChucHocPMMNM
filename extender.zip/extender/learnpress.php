<?php
/*
Plugin Name: LearnPress Custom Enhancer
Version: 1.3
Author: Chuc
*/

if ( ! defined( 'ABSPATH' ) ) exit;

require_once plugin_dir_path( __FILE__ ) . 'extender.php';

add_action( 'wp_enqueue_scripts', function() {
    // Thêm số version ngẫu nhiên để trình duyệt không lưu cache CSS cũ
    wp_enqueue_style( 'lpe-style', plugin_dir_url( __FILE__ ) . 'style.css', array(), time() );
});

// Dùng wp_footer để chắc chắn hiện ra
add_action( 'wp_footer', 'lpe_show_notification_bar' );

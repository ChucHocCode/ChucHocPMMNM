<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// YÊU CẦU 1: Lời chào
function lpe_show_notification_bar() {
    if ( ! is_singular( 'lp_course' ) ) {
        return;
    }

    $message = is_user_logged_in() 
        ? 'Chào ' . esc_html(wp_get_current_user()->display_name) . ', bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?' 
        : 'Đăng nhập để lưu tiến độ học tập!';

    echo '<div class="lpe-notification-bar">' . $message . '</div>';
}

// YÊU CẦU 2: Shortcode
function lpe_course_info_shortcode( $atts ) {
    $atts = shortcode_atts( array( 'id' => 0 ), $atts, 'lp_course_info' );
    $course_id = intval( $atts['id'] );
    if ( ! $course_id || ! function_exists( 'learn_press_get_course' ) ) return 'Vui lòng nhập ID khóa học.';

    $course = learn_press_get_course( $course_id );
    if ( ! $course ) return 'Khóa học không tồn tại.';

    $lessons = count( $course->get_items( LP_LESSON_CPT ) );
    $duration = $course->get_duration() ? $course->get_duration() : '10 weeks'; // Fallback theo ảnh của bạn

    $status_text = 'Chưa đăng ký';
    if ( is_user_logged_in() ) {
        $user = learn_press_get_user( get_current_user_id() );
        if ( $user->has_finished_course( $course_id ) ) $status_text = 'Đã hoàn thành';
        elseif ( $user->has_enrolled_course( $course_id ) ) $status_text = 'Đã đăng ký';
    }

    return "<div class='lpe-course-info'>
        <p>📚 <b>Bài học:</b> $lessons</p>
        <p>🕒 <b>Thời gian:</b> $duration</p>
        <p>📍 <b>Trạng thái:</b> $status_text</p>
    </div>";
}
add_shortcode( 'lp_course_info', 'lpe_course_info_shortcode' );
